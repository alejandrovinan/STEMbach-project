export const SIGN_UP_COMPLETED = "project/users/signUpCompleted";
export const LOGIN_COMPLETED = "project/users/loginCompleted";
export const LOGOUT = "project/users/logout";
export const UPDATE_PROFILE_COMPLETED = "project/users/updateProfileCompleted";
