export const LOADING = 'project/common/loading';
export const LOADED = 'project/common/loaded';
export const ERROR = 'project/common/error';
