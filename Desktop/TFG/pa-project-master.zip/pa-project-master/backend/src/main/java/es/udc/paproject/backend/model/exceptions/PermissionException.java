package es.udc.paproject.backend.model.exceptions;

@SuppressWarnings("serial")
public class PermissionException extends Exception {}
